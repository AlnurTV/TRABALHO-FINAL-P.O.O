package projetoFinal.steamRoxa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
