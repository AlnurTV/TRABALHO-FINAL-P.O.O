package projetoFinal.steamRoxa.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Game {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titulo;

    private String desenvolvedora;

    private String plataforma;     // Ex: PC, PS5, Xbox, Switch

    private String genero;         // Ex: Ação, RPG, Estratégia

    private Double nota;           // Avaliação de 0.0 a 10.0

    private Double preco;          // Preço opcional, mantido se quiser
}
